package co.edu.unisinu.abpProgramacion;


import co.edu.unisinu.abpVentana.VentanaAbp;




public class AbpPrincipal {

   
    public static void main(String[] args) {
        
        VentanaAbp ventana = new VentanaAbp();
        ventana.setLocationRelativeTo(null);
        ventana.setResizable(false);
        ventana.setVisible(true);
        
        
    }
    
}
