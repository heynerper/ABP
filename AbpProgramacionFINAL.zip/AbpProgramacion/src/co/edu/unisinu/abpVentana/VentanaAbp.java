
package co.edu.unisinu.abpVentana;

import co.edu.unisinu.procesos.*;
import java.awt.Image;
import java.awt.Toolkit;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.SpinnerNumberModel;
import javax.swing.filechooser.FileNameExtensionFilter;


public final class VentanaAbp extends javax.swing.JFrame {
    
    Articulos a = new Articulos();
    JFileChooser fc = new JFileChooser();
    FileNameExtensionFilter filtro = new FileNameExtensionFilter(".txt","txt");
    String txtBorrar;
    boolean numero;
    String v;
    char n;
    

  
    public VentanaAbp() {
        initComponents();
        numero = false;
        setIconImage(getIconImage());
    }

    @Override
    public Image getIconImage () { 
        
        Image retValue = Toolkit.getDefaultToolkit().getImage(ClassLoader.getSystemResource("Icono/llave.jpg"));
        
        return retValue;

    }
    
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        grupoProveedor = new javax.swing.ButtonGroup();
        dialogoDescripcion = new javax.swing.JDialog();
        jScrollPane1 = new javax.swing.JScrollPane();
        areaDescripcion = new javax.swing.JTextArea();
        PanelTitulo = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        btnAgrDescripcion = new javax.swing.JButton();
        dialogoVer = new javax.swing.JDialog();
        jToolBar2 = new javax.swing.JToolBar();
        btnAbrir = new javax.swing.JButton();
        jSeparator4 = new javax.swing.JToolBar.Separator();
        dvEliminar = new javax.swing.JButton();
        jSeparator6 = new javax.swing.JToolBar.Separator();
        dvSalir = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        areaVer = new javax.swing.JTextArea();
        dialogoContra = new javax.swing.JDialog();
        jPanel2 = new javax.swing.JPanel();
        jLabel13 = new javax.swing.JLabel();
        campoContraseña = new javax.swing.JTextField();
        campoVerificacion = new javax.swing.JTextField();
        btncontraseña = new javax.swing.JButton();
        jLabel14 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        etiError = new javax.swing.JLabel();
        EtiErrorCO = new javax.swing.JLabel();
        menuEmergente = new javax.swing.JPopupMenu();
        menucambiar = new javax.swing.JMenuItem();
        menuRecuperar = new javax.swing.JMenuItem();
        jToolBar1 = new javax.swing.JToolBar();
        btnGuardar = new javax.swing.JButton();
        jSeparator1 = new javax.swing.JToolBar.Separator();
        btnVer = new javax.swing.JButton();
        jSeparator2 = new javax.swing.JToolBar.Separator();
        btndemas = new javax.swing.JButton();
        jSeparator3 = new javax.swing.JToolBar.Separator();
        btnSalir = new javax.swing.JButton();
        panelTitulo = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        panelCuerpo = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        campoId = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        campoModelo = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        campoMarca = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        campoVenta = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        campoCompra = new javax.swing.JTextField();
        campoIva = new javax.swing.JTextField();
        jPanel1 = new javax.swing.JPanel();
        rdtPropio = new javax.swing.JRadioButton();
        rdtComprado = new javax.swing.JRadioButton();
        etiError7 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        campoTienda = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        spiCantidad = new javax.swing.JSpinner();
        jLabel11 = new javax.swing.JLabel();
        btnAgregar = new javax.swing.JButton();
        jLabel12 = new javax.swing.JLabel();
        campoCategoria = new javax.swing.JTextField();
        etiError1 = new javax.swing.JLabel();
        etiError1_2 = new javax.swing.JLabel();
        etiError2 = new javax.swing.JLabel();
        etiError3 = new javax.swing.JLabel();
        etiError3_2 = new javax.swing.JLabel();
        etiError4 = new javax.swing.JLabel();
        etiError4_2 = new javax.swing.JLabel();
        etiError5 = new javax.swing.JLabel();
        etiError5_2 = new javax.swing.JLabel();
        etiError6 = new javax.swing.JLabel();
        etiError8 = new javax.swing.JLabel();
        etiError9 = new javax.swing.JLabel();
        etiError10 = new javax.swing.JLabel();

        dialogoDescripcion.setTitle("DESCRIPTION WINDOW");
        dialogoDescripcion.setIconImage(getIconImage());
        dialogoDescripcion.setModal(true);

        areaDescripcion.setColumns(20);
        areaDescripcion.setRows(5);
        jScrollPane1.setViewportView(areaDescripcion);

        PanelTitulo.setBackground(new java.awt.Color(0, 153, 153));

        jLabel2.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        jLabel2.setText("Ingrese una corta descripcion");
        PanelTitulo.add(jLabel2);

        btnAgrDescripcion.setFont(new java.awt.Font("Times New Roman", 0, 12)); // NOI18N
        btnAgrDescripcion.setText("Agregar");
        btnAgrDescripcion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAgrDescripcionActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout dialogoDescripcionLayout = new javax.swing.GroupLayout(dialogoDescripcion.getContentPane());
        dialogoDescripcion.getContentPane().setLayout(dialogoDescripcionLayout);
        dialogoDescripcionLayout.setHorizontalGroup(
            dialogoDescripcionLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(PanelTitulo, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(dialogoDescripcionLayout.createSequentialGroup()
                .addGroup(dialogoDescripcionLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(dialogoDescripcionLayout.createSequentialGroup()
                        .addGap(74, 74, 74)
                        .addComponent(btnAgrDescripcion))
                    .addGroup(dialogoDescripcionLayout.createSequentialGroup()
                        .addGap(34, 34, 34)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 145, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        dialogoDescripcionLayout.setVerticalGroup(
            dialogoDescripcionLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, dialogoDescripcionLayout.createSequentialGroup()
                .addComponent(PanelTitulo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btnAgrDescripcion)
                .addContainerGap(19, Short.MAX_VALUE))
        );

        dialogoVer.setTitle("OUTPUT WINDOW");
        dialogoVer.setIconImage(getIconImage());
        dialogoVer.setModal(true);

        jToolBar2.setRollover(true);

        btnAbrir.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        btnAbrir.setText("Abrir");
        btnAbrir.setFocusable(false);
        btnAbrir.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnAbrir.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btnAbrir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAbrirActionPerformed(evt);
            }
        });
        jToolBar2.add(btnAbrir);
        jToolBar2.add(jSeparator4);

        dvEliminar.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        dvEliminar.setText("Eliminar");
        dvEliminar.setFocusable(false);
        dvEliminar.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        dvEliminar.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        dvEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                dvEliminarActionPerformed(evt);
            }
        });
        jToolBar2.add(dvEliminar);
        jToolBar2.add(jSeparator6);

        dvSalir.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        dvSalir.setText("Salir");
        dvSalir.setFocusable(false);
        dvSalir.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        dvSalir.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        dvSalir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                dvSalirActionPerformed(evt);
            }
        });
        jToolBar2.add(dvSalir);

        areaVer.setColumns(20);
        areaVer.setRows(5);
        jScrollPane2.setViewportView(areaVer);

        javax.swing.GroupLayout dialogoVerLayout = new javax.swing.GroupLayout(dialogoVer.getContentPane());
        dialogoVer.getContentPane().setLayout(dialogoVerLayout);
        dialogoVerLayout.setHorizontalGroup(
            dialogoVerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jToolBar2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 400, Short.MAX_VALUE)
        );
        dialogoVerLayout.setVerticalGroup(
            dialogoVerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(dialogoVerLayout.createSequentialGroup()
                .addComponent(jToolBar2, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 269, Short.MAX_VALUE))
        );

        dialogoContra.setTitle("PASSWORD WINDOW");
        dialogoContra.setIconImage(getIconImage());
        dialogoContra.setModal(true);

        jPanel2.setBackground(new java.awt.Color(0, 153, 153));
        jPanel2.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        jLabel13.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        jLabel13.setText("Ingrese la contraseña");
        jPanel2.add(jLabel13);

        btncontraseña.setText("Aceptar");
        btncontraseña.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btncontraseñaActionPerformed(evt);
            }
        });

        jLabel14.setText("Contraseña");

        jLabel15.setText("Confirmacion");

        etiError.setFont(new java.awt.Font("Times New Roman", 0, 12)); // NOI18N
        etiError.setForeground(new java.awt.Color(255, 0, 0));

        EtiErrorCO.setFont(new java.awt.Font("Times New Roman", 0, 12)); // NOI18N
        EtiErrorCO.setForeground(new java.awt.Color(255, 0, 0));

        javax.swing.GroupLayout dialogoContraLayout = new javax.swing.GroupLayout(dialogoContra.getContentPane());
        dialogoContra.getContentPane().setLayout(dialogoContraLayout);
        dialogoContraLayout.setHorizontalGroup(
            dialogoContraLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(dialogoContraLayout.createSequentialGroup()
                .addGroup(dialogoContraLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(dialogoContraLayout.createSequentialGroup()
                        .addGap(51, 51, 51)
                        .addGroup(dialogoContraLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(dialogoContraLayout.createSequentialGroup()
                                .addComponent(jLabel15)
                                .addGap(18, 18, 18)
                                .addComponent(EtiErrorCO, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(campoContraseña, javax.swing.GroupLayout.PREFERRED_SIZE, 156, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(dialogoContraLayout.createSequentialGroup()
                                .addComponent(jLabel14)
                                .addGap(18, 18, 18)
                                .addComponent(etiError, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(campoVerificacion, javax.swing.GroupLayout.PREFERRED_SIZE, 156, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(dialogoContraLayout.createSequentialGroup()
                        .addGap(87, 87, 87)
                        .addComponent(btncontraseña)))
                .addContainerGap(33, Short.MAX_VALUE))
        );
        dialogoContraLayout.setVerticalGroup(
            dialogoContraLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(dialogoContraLayout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(dialogoContraLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel14)
                    .addComponent(etiError, javax.swing.GroupLayout.PREFERRED_SIZE, 14, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(campoContraseña, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(dialogoContraLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel15)
                    .addComponent(EtiErrorCO, javax.swing.GroupLayout.PREFERRED_SIZE, 14, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(campoVerificacion, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btncontraseña)
                .addContainerGap(35, Short.MAX_VALUE))
        );

        menucambiar.setText("Cambiar contraseña");
        menucambiar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menucambiarActionPerformed(evt);
            }
        });
        menuEmergente.add(menucambiar);

        menuRecuperar.setText("Recupera contraseña");
        menuRecuperar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menuRecuperarActionPerformed(evt);
            }
        });
        menuEmergente.add(menuRecuperar);

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("PRINCIPAL WINDOW");

        jToolBar1.setRollover(true);
        jToolBar1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jToolBar1MouseClicked(evt);
            }
        });

        btnGuardar.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        btnGuardar.setText("Guardar");
        btnGuardar.setFocusable(false);
        btnGuardar.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnGuardar.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btnGuardar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGuardarActionPerformed(evt);
            }
        });
        jToolBar1.add(btnGuardar);
        jToolBar1.add(jSeparator1);

        btnVer.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        btnVer.setText("Ver");
        btnVer.setFocusable(false);
        btnVer.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnVer.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btnVer.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnVerActionPerformed(evt);
            }
        });
        jToolBar1.add(btnVer);
        jToolBar1.add(jSeparator2);

        btndemas.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        btndemas.setText("Acerca");
        btndemas.setFocusable(false);
        btndemas.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btndemas.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btndemas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btndemasActionPerformed(evt);
            }
        });
        jToolBar1.add(btndemas);
        jToolBar1.add(jSeparator3);

        btnSalir.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        btnSalir.setText("Salir");
        btnSalir.setFocusable(false);
        btnSalir.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnSalir.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btnSalir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSalirActionPerformed(evt);
            }
        });
        jToolBar1.add(btnSalir);

        panelTitulo.setBackground(new java.awt.Color(0, 153, 153));
        panelTitulo.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        panelTitulo.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N

        jLabel1.setFont(new java.awt.Font("Times New Roman", 0, 24)); // NOI18N
        jLabel1.setText("INVENTARIO DE ARTICULOS ");
        jLabel1.setBorder(javax.swing.BorderFactory.createEtchedBorder(javax.swing.border.EtchedBorder.RAISED));
        panelTitulo.add(jLabel1);

        panelCuerpo.setBackground(new java.awt.Color(204, 204, 204));
        panelCuerpo.setBorder(javax.swing.BorderFactory.createCompoundBorder(null, new javax.swing.border.MatteBorder(null)));
        panelCuerpo.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel3.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        jLabel3.setText("ID del Producto: ");
        panelCuerpo.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(11, 22, 100, 31));

        campoId.setFont(new java.awt.Font("Times New Roman", 0, 12)); // NOI18N
        campoId.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        campoId.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                campoIdKeyTyped(evt);
            }
        });
        panelCuerpo.add(campoId, new org.netbeans.lib.awtextra.AbsoluteConstraints(141, 23, 125, 31));

        jLabel4.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        jLabel4.setText("Modelo :");
        panelCuerpo.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(11, 369, 78, 32));

        campoModelo.setFont(new java.awt.Font("Times New Roman", 0, 12)); // NOI18N
        campoModelo.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        panelCuerpo.add(campoModelo, new org.netbeans.lib.awtextra.AbsoluteConstraints(141, 371, 125, 31));

        jLabel5.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        jLabel5.setText("Marca del producto:");
        panelCuerpo.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(11, 93, -1, 31));

        campoMarca.setFont(new java.awt.Font("Times New Roman", 0, 12)); // NOI18N
        campoMarca.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        panelCuerpo.add(campoMarca, new org.netbeans.lib.awtextra.AbsoluteConstraints(143, 94, 125, 31));

        jLabel6.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        jLabel6.setText("Precio venta: ");
        panelCuerpo.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(11, 166, -1, 31));

        campoVenta.setFont(new java.awt.Font("Times New Roman", 0, 12)); // NOI18N
        campoVenta.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        campoVenta.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                campoVentaKeyTyped(evt);
            }
        });
        panelCuerpo.add(campoVenta, new org.netbeans.lib.awtextra.AbsoluteConstraints(143, 167, 125, 31));

        jLabel7.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        jLabel7.setText("Precio compra: ");
        panelCuerpo.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(11, 240, -1, 31));

        jLabel8.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        jLabel8.setText("Iva del producto %:");
        panelCuerpo.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(11, 309, -1, 31));

        campoCompra.setFont(new java.awt.Font("Times New Roman", 0, 12)); // NOI18N
        campoCompra.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        campoCompra.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                campoCompraKeyTyped(evt);
            }
        });
        panelCuerpo.add(campoCompra, new org.netbeans.lib.awtextra.AbsoluteConstraints(143, 241, 125, 31));

        campoIva.setFont(new java.awt.Font("Times New Roman", 0, 12)); // NOI18N
        campoIva.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        campoIva.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                campoIvaKeyTyped(evt);
            }
        });
        panelCuerpo.add(campoIva, new org.netbeans.lib.awtextra.AbsoluteConstraints(141, 310, 125, 31));

        jPanel1.setBackground(new java.awt.Color(204, 204, 204));
        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(0, 0, 0), new java.awt.Color(0, 0, 0), new java.awt.Color(0, 0, 0), new java.awt.Color(0, 0, 0)), "Proveedor"));

        rdtPropio.setBackground(new java.awt.Color(204, 204, 204));
        grupoProveedor.add(rdtPropio);
        rdtPropio.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        rdtPropio.setText("Propio");

        rdtComprado.setBackground(new java.awt.Color(204, 204, 204));
        grupoProveedor.add(rdtComprado);
        rdtComprado.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        rdtComprado.setText("Comprado");

        etiError7.setFont(new java.awt.Font("Times New Roman", 0, 12)); // NOI18N
        etiError7.setForeground(new java.awt.Color(255, 0, 0));

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(rdtComprado, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(rdtPropio, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(etiError7, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(etiError7, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(rdtPropio)
                .addGap(18, 18, 18)
                .addComponent(rdtComprado)
                .addGap(21, 21, 21))
        );

        panelCuerpo.add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 10, -1, -1));

        jLabel9.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        jLabel9.setText("Tienda:");
        panelCuerpo.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(306, 167, -1, 32));

        campoTienda.setFont(new java.awt.Font("Times New Roman", 0, 12)); // NOI18N
        campoTienda.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        panelCuerpo.add(campoTienda, new org.netbeans.lib.awtextra.AbsoluteConstraints(385, 169, 125, 31));

        jLabel10.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        jLabel10.setText("Cantidad:");
        panelCuerpo.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(306, 239, -1, 32));

        SpinnerNumberModel nm = new SpinnerNumberModel();
        nm.setMinimum(0);
        nm.setStepSize(2);
        spiCantidad.setModel(nm);
        spiCantidad.setValue(0);
        spiCantidad.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        spiCantidad.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        spiCantidad.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                spiCantidadStateChanged(evt);
            }
        });
        panelCuerpo.add(spiCantidad, new org.netbeans.lib.awtextra.AbsoluteConstraints(385, 239, 125, 33));

        jLabel11.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        jLabel11.setText("Descripcion: ");
        panelCuerpo.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(306, 308, -1, 32));

        btnAgregar.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        btnAgregar.setText("Agregar");
        btnAgregar.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnAgregar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAgregarActionPerformed(evt);
            }
        });
        panelCuerpo.add(btnAgregar, new org.netbeans.lib.awtextra.AbsoluteConstraints(385, 308, 125, 33));

        jLabel12.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        jLabel12.setText("Categoria:");
        panelCuerpo.add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(306, 369, -1, 32));

        campoCategoria.setFont(new java.awt.Font("Times New Roman", 0, 12)); // NOI18N
        campoCategoria.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        campoCategoria.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                campoCategoriaKeyTyped(evt);
            }
        });
        panelCuerpo.add(campoCategoria, new org.netbeans.lib.awtextra.AbsoluteConstraints(385, 371, 125, 31));

        etiError1.setFont(new java.awt.Font("Times New Roman", 0, 12)); // NOI18N
        etiError1.setForeground(new java.awt.Color(255, 0, 0));
        panelCuerpo.add(etiError1, new org.netbeans.lib.awtextra.AbsoluteConstraints(141, 11, 140, 10));

        etiError1_2.setFont(new java.awt.Font("Times New Roman", 0, 12)); // NOI18N
        etiError1_2.setForeground(new java.awt.Color(255, 0, 0));
        panelCuerpo.add(etiError1_2, new org.netbeans.lib.awtextra.AbsoluteConstraints(141, 11, 140, 10));

        etiError2.setFont(new java.awt.Font("Times New Roman", 0, 12)); // NOI18N
        etiError2.setForeground(new java.awt.Color(255, 0, 0));
        panelCuerpo.add(etiError2, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 80, 120, 10));

        etiError3.setFont(new java.awt.Font("Times New Roman", 0, 12)); // NOI18N
        etiError3.setForeground(new java.awt.Color(255, 0, 0));
        panelCuerpo.add(etiError3, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 140, 140, 20));

        etiError3_2.setFont(new java.awt.Font("Times New Roman", 0, 12)); // NOI18N
        etiError3_2.setForeground(new java.awt.Color(255, 0, 0));
        panelCuerpo.add(etiError3_2, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 140, 140, 20));

        etiError4.setFont(new java.awt.Font("Times New Roman", 0, 12)); // NOI18N
        etiError4.setForeground(new java.awt.Color(255, 0, 0));
        panelCuerpo.add(etiError4, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 220, 140, 20));

        etiError4_2.setFont(new java.awt.Font("Times New Roman", 0, 12)); // NOI18N
        etiError4_2.setForeground(new java.awt.Color(255, 0, 0));
        panelCuerpo.add(etiError4_2, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 220, 140, 20));

        etiError5.setFont(new java.awt.Font("Times New Roman", 0, 12)); // NOI18N
        etiError5.setForeground(new java.awt.Color(255, 0, 0));
        panelCuerpo.add(etiError5, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 290, 130, 20));

        etiError5_2.setFont(new java.awt.Font("Times New Roman", 0, 12)); // NOI18N
        etiError5_2.setForeground(new java.awt.Color(255, 0, 0));
        panelCuerpo.add(etiError5_2, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 290, 130, 20));

        etiError6.setFont(new java.awt.Font("Times New Roman", 0, 12)); // NOI18N
        etiError6.setForeground(new java.awt.Color(255, 0, 0));
        panelCuerpo.add(etiError6, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 350, 110, 20));

        etiError8.setFont(new java.awt.Font("Times New Roman", 0, 12)); // NOI18N
        etiError8.setForeground(new java.awt.Color(255, 0, 0));
        panelCuerpo.add(etiError8, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 150, 120, 20));

        etiError9.setFont(new java.awt.Font("Times New Roman", 0, 12)); // NOI18N
        etiError9.setForeground(new java.awt.Color(255, 0, 0));
        panelCuerpo.add(etiError9, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 280, 120, 20));

        etiError10.setFont(new java.awt.Font("Times New Roman", 0, 12)); // NOI18N
        etiError10.setForeground(new java.awt.Color(255, 0, 0));
        panelCuerpo.add(etiError10, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 350, 120, 20));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(panelCuerpo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(panelTitulo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jToolBar1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jToolBar1, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(3, 3, 3)
                .addComponent(panelTitulo, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(panelCuerpo, javax.swing.GroupLayout.PREFERRED_SIZE, 430, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnGuardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGuardarActionPerformed
        // TODO add your handling code here:
        
        if(numero == false){
            dialogoContra.setSize(300, 300);
            dialogoContra.setLocationRelativeTo(null);
            dialogoContra.setResizable(false);
            dialogoContra.setVisible(true);
        }
        v = campoVerificacion.getText();
        if(v.equals(a.password)){
             
            try{
                
                if(Integer.parseInt(campoId.getText()) > 0){
                a.id= Integer.parseInt(campoId.getText());
                etiError1_2.setText("");
                etiError1.setText("");
                }
                if(Integer.parseInt(campoId.getText()) < 0){
                    etiError1.setText("El ID debe ser mayor a cero");
                    etiError1_2.setText("");
                }
               
            }catch(Throwable e){
                if(campoId.getText().isEmpty()){
                    etiError1_2.setText("*campo obligatorio");
                }else{
                    etiError1_2.setText("El ID deben ser numeros");
                    etiError1.setText("");
                }
            }

            String m = campoMarca.getText().trim();
                if(m.isEmpty()== false){
                    a.marca= m;
                    etiError2.setText("");
                }else{
                    etiError2.setText("* campo obligatorio");
                }

            try{
                if(Float.parseFloat(campoVenta.getText()) > 0){
                   a.precioVenta= Float.parseFloat(campoVenta.getText());
                   etiError3_2.setText("");
                   etiError3.setText("");
                }
                if(Float.parseFloat(campoVenta.getText()) < 0){
                    etiError3.setText("El precio debe ser mayor a cero");
                    etiError3_2.setText("");
                }
                
               
            }catch(Throwable e){
                 if(campoVenta.getText().isEmpty()){
                    etiError3_2.setText("*campo obligatorio");
                }else{
                    etiError3_2.setText("El precio deben ser numeros");
                    etiError3.setText("");
                 }
             }

            try{
                if(Float.parseFloat(campoCompra.getText()) > 0){
                   a.precioCompra= Float.parseFloat(campoCompra.getText());
                   etiError4_2.setText("");
                   etiError4.setText("");
                }
                if(Float.parseFloat(campoCompra.getText()) < 0){
                    etiError4.setText("El precio debe ser mayor a cero");
                    etiError4_2.setText("");
                }
                
            }catch(Throwable e){
                if(campoCompra.getText().isEmpty()){
                    etiError4_2.setText("*campo obligatorio");
                }else{
                    etiError4_2.setText("El precio deben ser numeros");
                    etiError4.setText("");
                }
            }

            try{
                if(Integer.parseInt(campoIva.getText()) > 0){
                   a.iva = Float.parseFloat(campoIva.getText());
                   etiError5_2.setText("");
                   etiError5.setText("");
                }
                if(Float.parseFloat(campoIva.getText()) < 0){
                    etiError5.setText("El Iva debe ser mayor a cero");
                    etiError5_2.setText("");
                }
               
            }catch(Throwable e){
                 if(campoIva.getText().isEmpty()){
                    etiError5_2.setText("*campo obligatorio");
                 }else{
                    etiError5_2.setText("El IVA deben ser numeros");
                    etiError5.setText("");
                 }
            }

            String md = campoModelo.getText().trim();
            if(md.isEmpty()== false){
                a.modelo= md;
                etiError6.setText("");
            }else{
                etiError6.setText("* campo obigatorio");
            }

            if(rdtPropio.isSelected()){
                a.proveedor = "Propio";
                etiError7.setText("");
            }
            if(rdtComprado.isSelected()){
                a.proveedor = "Comprado";
                etiError7.setText("");
            }
            if(!rdtComprado.isSelected()&&!rdtPropio.isSelected()){
                etiError7.setText("*campo obligatorio");
            }

            String ti = campoTienda.getText().trim();
            if(ti.isEmpty()== false){
                a.tienda= ti;
                etiError8.setText("");
            }else{
                etiError8.setText("* campo obigatorio");
            }

            String cate = campoCategoria.getText().trim();
            if(cate.isEmpty()== false){
                a.categoria= cate;
                etiError10.setText("");
            }else{
                etiError10.setText("* campo obigatorio");
            }
            if(areaDescripcion.getText().isEmpty()){
                etiError9.setText("Agrege una descripcion");
            }
            try{
                if(a.id>0){
                if(!a.marca.isEmpty()){
                   if(a.precioVenta>0){
                       if(a.precioCompra>0){
                            if(a.iva>0){
                                if(!a.modelo.isEmpty()){
                                    if(!a.proveedor.isEmpty()){
                                        if(!a.tienda.isEmpty()){
                                            if(a.cantidad>0){
                                                if(!a.descripcion.isEmpty()){
                                                    if(!a.categoria.isEmpty()){
                                                        areaVer.setText("El Id del producto es: "+a.id+"\n"+
                                                                        "La marca del producto es: "+a.marca+"\n"+
                                                                        "El precio de venta es: $"+a.precioVenta+"\n"+
                                                                        "El precio de compra es: $"+a.precioCompra+"\n"+
                                                                        "El iva del producto es: %"+a.iva+"\n"+
                                                                        "El modelo del producto es: "+a.modelo+"\n"+
                                                                        "El proveedor es: "+a.proveedor+"\n"+
                                                                        "La tienda del producto es: "+a.tienda+"\n"+
                                                                        "La cantidad del pructo es: "+a.cantidad+"\n"+
                                                                        "Descripcion: "+a.descripcion+"\n"+
                                                                        "Categoria: "+a.categoria+"\n");
                                                       
                                                        fc.setFileFilter(filtro);
                                                        fc.setSelectedFile(new File(a.modelo + ".txt"));
                                                        int seleccion = fc.showSaveDialog(this);

                                                        if(seleccion == JFileChooser.APPROVE_OPTION){
                                                            File fichero = fc.getSelectedFile();
                                                            txtBorrar =(fichero.getAbsolutePath());
                                                            
                                                            Boolean vrf;

                                                            try(FileWriter fw = new FileWriter(fichero)){
                                                                
                                                                fw.write(this.areaVer.getText());
                                                                vrf = true;

                                                            } catch (IOException ex) {
                                                                
                                                                JOptionPane.showMessageDialog(null, "Hubo un error al guardar el archivo, vuelva a intentar");
                                                                vrf = false;
                                                            }

                                                            if(vrf == true){
                                                                 numero= true;
                                                                 a.id++;
                                                                 campoId.setText(""+a.id);
                                                                 campoMarca.setText("");
                                                                 campoVenta.setText("");
                                                                 campoCompra.setText("");
                                                                 campoIva.setText("");
                                                                 campoModelo.setText("");
                                                                 campoTienda.setText("");
                                                                 areaDescripcion.setText("");
                                                                 campoCategoria.setText("");
                                                                 grupoProveedor.clearSelection();
                                                                 spiCantidad.setValue(0);
                                                                JOptionPane.showMessageDialog(null, "Se ha guardado el archivo correctamente");
                                                            }
                                                            if(vrf == false){
                                                                JOptionPane.showMessageDialog(null, "Hubo un error al guardar el archivo, vuelva a intentar");
                                                            }

                                                        }
                                                         
                                                    }
                                                }
                                            }
                                        }

                                    }
                                }
                            }
                        }
                    }
                }
            }
            
            
            }catch(Throwable e){
            
            }
            

        }
         
      
    }//GEN-LAST:event_btnGuardarActionPerformed

    private void btnSalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSalirActionPerformed
        // TODO add your handling code here:
        this.dispose();
    }//GEN-LAST:event_btnSalirActionPerformed

    private void spiCantidadStateChanged(javax.swing.event.ChangeEvent evt) {//GEN-FIRST:event_spiCantidadStateChanged
        // TODO add your handling code here:
        
        a.cantidad= Integer.parseInt(spiCantidad.getValue().toString());
    }//GEN-LAST:event_spiCantidadStateChanged

    private void btnAgregarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAgregarActionPerformed
        // TODO add your handling code here:
            dialogoDescripcion.setSize(250,200);
            dialogoDescripcion.setLocationRelativeTo(null);
            dialogoDescripcion.setResizable(false);
            dialogoDescripcion.setVisible(true);
        
    }//GEN-LAST:event_btnAgregarActionPerformed

    private void btnAgrDescripcionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAgrDescripcionActionPerformed
        // TODO add your handling code here:
        
        String d = areaDescripcion.getText().trim();
        if(d.isEmpty()== false){
            a.descripcion= d;
            etiError9.setText("");
            this.dialogoDescripcion.dispose();
            
            
        }else{
            etiError9.setText("Agrege una descripcion");
        }
    }//GEN-LAST:event_btnAgrDescripcionActionPerformed

    private void btncontraseñaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btncontraseñaActionPerformed
        // TODO add your handling code here:
        
        
        String contraseña = campoContraseña.getText().trim();
        
        if(contraseña.isEmpty() == false && contraseña.length() >= 8 ){
            int  Numeros = 0, LetraMay = 0, caracter =0;
            for (int i = 0; i < contraseña.length()  ; i++) {
                char clave = contraseña.charAt(i);
                if (Character.isUpperCase(clave)) {
                    LetraMay++;
                }
                if (!Character.isLetterOrDigit(clave)) {
                    caracter++;
                }
                if (Character.isDigit(clave)) {
                    Numeros++;
                }
            }
            if(Numeros>=1 && LetraMay>=1 && caracter>=1 ){
                a.password = contraseña;
                v = campoVerificacion.getText();
                if(v.equals(a.password)){
                    etiError.setText("");
                    this.dialogoContra.dispose();
                }else{
                JOptionPane.showMessageDialog(null,"Las contraseñas no coinciden","ERROR",JOptionPane.ERROR_MESSAGE);
                }
              
            }
            
            if(Numeros == 0){
                
                etiError.setText("Error");
                
            }
            if(LetraMay == 0){
                
                etiError.setText("Error");
            }
            if(caracter == 0){
               
                etiError.setText("Error");
            }
            if(contraseña.length()< 8){
                
                etiError.setText("Error");
            }
        }else if(contraseña.isEmpty()== true){
             etiError.setText("*Campo obligatorio");
        }
        
        
    }//GEN-LAST:event_btncontraseñaActionPerformed

    private void btnVerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnVerActionPerformed
        // TODO add your handling code here:
        try{
            if(numero == false){
                String v = JOptionPane.showInputDialog(null,"Ingrese contraseña","PASSWORD",JOptionPane .INFORMATION_MESSAGE);
                if(v.equals(a.password)){
                    dialogoVer.setSize(400,300);
                    dialogoVer.setLocationRelativeTo(null);
                    dialogoVer.setResizable(false);
                    dialogoVer.setVisible(true);
                }else{
                    JOptionPane.showMessageDialog(null,"Contrseña incorrecta","ERROR",JOptionPane.ERROR_MESSAGE);
                }
            }else{
                JOptionPane.showMessageDialog(null,"NO hay nada agregado","INVALID OPTION",JOptionPane.ERROR_MESSAGE);
            }
        }catch(Throwable e){
            
        }
                            
        
        
    }//GEN-LAST:event_btnVerActionPerformed

    private void btndemasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btndemasActionPerformed
        // TODO add your handling code here:
        JOptionPane.showMessageDialog(null,"Desarrollado por: \n"+
                                           "   *Heyner Perdomo\n   *Jacob Salcedo\n   *Juan Ariza\n"
                                            ,"CREDITS",JOptionPane.INFORMATION_MESSAGE);
    }//GEN-LAST:event_btndemasActionPerformed

    private void dvSalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_dvSalirActionPerformed
        // TODO add your handling code here:
        this.dialogoVer.dispose();
    }//GEN-LAST:event_dvSalirActionPerformed

    private void btnAbrirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAbrirActionPerformed
        // TODO add your handling code here:
        
        fc.setFileFilter(filtro);
        
        int seleccion = fc.showOpenDialog(this);
        
        if(seleccion == JFileChooser.APPROVE_OPTION){
            File fichero = fc.getSelectedFile();
            txtBorrar=(fichero.getAbsolutePath());
            
            try(FileReader fr = new FileReader(fichero)){
                String cadena = "";
                int valor = fr.read();
                while(valor != -1){
                    cadena = cadena + (char) valor;
                    valor = fr.read();
                }
                this.areaVer.setText(cadena);
                
            } catch (IOException ex) {
                
                JOptionPane.showMessageDialog(null, "hubo un error, vuelva a intenar.");
            }
            
            
        }
        
    }//GEN-LAST:event_btnAbrirActionPerformed

    private void dvEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_dvEliminarActionPerformed
        // TODO add your handling code here:
        File archivo = new File (txtBorrar);
        try{
            if(archivo.delete()){
                areaVer.setText("");
                JOptionPane.showMessageDialog(null,"Se elimino con exito");
            }else{
                JOptionPane.showMessageDialog(null,"Hubo un error, vuelva a intentar");
            }
        }catch(Throwable error){
            JOptionPane.showMessageDialog(null,"error -> "+error);
        }
    }//GEN-LAST:event_dvEliminarActionPerformed

    private void jToolBar1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jToolBar1MouseClicked
        // TODO add your handling code here:
         if (evt.getButton()==3) {
            menuEmergente.show(this,evt.getX(),evt.getY());
        }
      
    }//GEN-LAST:event_jToolBar1MouseClicked

    private void menucambiarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menucambiarActionPerformed
        // TODO add your handling code here:
        try{
            if(a.password.isEmpty()== false){
                dialogoContra.setSize(300, 300);
                dialogoContra.setLocationRelativeTo(null);
                dialogoContra.setResizable(false);
                dialogoContra.setVisible(true); 
            }
        }catch(Throwable e){
            JOptionPane.showMessageDialog(null,"No hay contraseña que cambiar","OPCION INVALIDA",JOptionPane.ERROR_MESSAGE);
        }   
    }//GEN-LAST:event_menucambiarActionPerformed

    private void menuRecuperarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menuRecuperarActionPerformed
        // TODO add your handling code here:
        try{
            if(a.password.isEmpty()== false){
                JOptionPane.showMessageDialog(null, a.password+"  ¡¡¡NO la olvides!!!","TU CONTRASEÑA ES",JOptionPane.WARNING_MESSAGE);
            }
        }catch(Throwable e){
            JOptionPane.showMessageDialog(null,"No hay ninguna contraseña que recuperar","OPCION INVALIDA",JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_menuRecuperarActionPerformed

    private void campoIdKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_campoIdKeyTyped
        // TODO add your handling code here:
        
        n = evt.getKeyChar();
        if(n < '0' || n > '9'){
                evt.consume();
        }
    }//GEN-LAST:event_campoIdKeyTyped

    private void campoVentaKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_campoVentaKeyTyped
        // TODO add your handling code here:
         n = evt.getKeyChar();
         
         if(n < '0' || n > '9'){
            evt.consume();
         }
        
    }//GEN-LAST:event_campoVentaKeyTyped

    private void campoCompraKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_campoCompraKeyTyped
        // TODO add your handling code here:
        n = evt.getKeyChar();
         
         if(n < '0' || n > '9'){
            evt.consume();
         }
        
    }//GEN-LAST:event_campoCompraKeyTyped

    private void campoIvaKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_campoIvaKeyTyped
        // TODO add your handling code here:
         n = evt.getKeyChar();
         
         if(n < '0' || n > '9'){
            evt.consume();
         }
    }//GEN-LAST:event_campoIvaKeyTyped

    private void campoCategoriaKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_campoCategoriaKeyTyped
        // TODO add your handling code here:
        n= evt.getKeyChar();
        
        if((n< 'a'||n>'z')&&(n<'A'||n>'Z')){
            evt.consume();
        }
    }//GEN-LAST:event_campoCategoriaKeyTyped

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(VentanaAbp.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(VentanaAbp.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(VentanaAbp.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(VentanaAbp.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new VentanaAbp().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel EtiErrorCO;
    private javax.swing.JPanel PanelTitulo;
    private javax.swing.JTextArea areaDescripcion;
    private javax.swing.JTextArea areaVer;
    private javax.swing.JButton btnAbrir;
    private javax.swing.JButton btnAgrDescripcion;
    private javax.swing.JButton btnAgregar;
    private javax.swing.JButton btnGuardar;
    private javax.swing.JButton btnSalir;
    private javax.swing.JButton btnVer;
    private javax.swing.JButton btncontraseña;
    private javax.swing.JButton btndemas;
    private javax.swing.JTextField campoCategoria;
    private javax.swing.JTextField campoCompra;
    private javax.swing.JTextField campoContraseña;
    private javax.swing.JTextField campoId;
    private javax.swing.JTextField campoIva;
    private javax.swing.JTextField campoMarca;
    private javax.swing.JTextField campoModelo;
    private javax.swing.JTextField campoTienda;
    private javax.swing.JTextField campoVenta;
    private javax.swing.JTextField campoVerificacion;
    private javax.swing.JDialog dialogoContra;
    private javax.swing.JDialog dialogoDescripcion;
    private javax.swing.JDialog dialogoVer;
    private javax.swing.JButton dvEliminar;
    private javax.swing.JButton dvSalir;
    private javax.swing.JLabel etiError;
    private javax.swing.JLabel etiError1;
    private javax.swing.JLabel etiError10;
    private javax.swing.JLabel etiError1_2;
    private javax.swing.JLabel etiError2;
    private javax.swing.JLabel etiError3;
    private javax.swing.JLabel etiError3_2;
    private javax.swing.JLabel etiError4;
    private javax.swing.JLabel etiError4_2;
    private javax.swing.JLabel etiError5;
    private javax.swing.JLabel etiError5_2;
    private javax.swing.JLabel etiError6;
    private javax.swing.JLabel etiError7;
    private javax.swing.JLabel etiError8;
    private javax.swing.JLabel etiError9;
    private javax.swing.ButtonGroup grupoProveedor;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JToolBar.Separator jSeparator1;
    private javax.swing.JToolBar.Separator jSeparator2;
    private javax.swing.JToolBar.Separator jSeparator3;
    private javax.swing.JToolBar.Separator jSeparator4;
    private javax.swing.JToolBar.Separator jSeparator6;
    private javax.swing.JToolBar jToolBar1;
    private javax.swing.JToolBar jToolBar2;
    private javax.swing.JPopupMenu menuEmergente;
    private javax.swing.JMenuItem menuRecuperar;
    private javax.swing.JMenuItem menucambiar;
    private javax.swing.JPanel panelCuerpo;
    private javax.swing.JPanel panelTitulo;
    private javax.swing.JRadioButton rdtComprado;
    private javax.swing.JRadioButton rdtPropio;
    private javax.swing.JSpinner spiCantidad;
    // End of variables declaration//GEN-END:variables
}
