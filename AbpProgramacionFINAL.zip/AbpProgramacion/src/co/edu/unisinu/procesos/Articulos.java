
package co.edu.unisinu.procesos;


public class Articulos {
    
    public int id;
    public String marca;
    public String password;
    public float precioVenta;
    public float precioCompra;
    public float iva;
    public String modelo;
    public String proveedor;
    public String tienda;
    public int cantidad;
    public String descripcion;
    public String categoria;
      
}
